% Find significant locations using a robust cell that didn't change much
% it's 3D cell shape over two consecutive time points
%Example:

%Set the MATLAB path at the folder image called
%"Experimenting_TrjctID_0005".

%..../Experimenting_TrjctID_0005


Testing_Time_Point = 25;

Number_of_Signatures = 8;

Starting_Traj = 1;

Number_of_Traj = 1;

%******************************************************************
Starting_Traj = Starting_Traj + 2; % because "files" strats from 3
Number_of_Traj = Number_of_Traj + 2; % because "files" strats from 3
%******************************************************************

Root = pwd;

files = dir(Root);
net = resnet101();
inputSize = net.Layers(1).InputSize;

for all_Traj = Starting_Traj:Number_of_Traj
    Traj_Directory = {files(all_Traj).name};
    Traj_Address = strcat(Root, '\', Traj_Directory);
    Traj_Address = cell2mat(Traj_Address)
    
    S = dir(Traj_Address);
    number_of_Subfolders = sum([S(~ismember({S.name},{'.','..'})).isdir]);
    
    Experiment_Address = strcat(Root, '\', Traj_Directory);
    Experiment_Address = cell2mat(Experiment_Address);
    cd (Experiment_Address)  % go to the experiment address
    
    All_Results = [];
    
    %*******************************************************
    %                  Start CNN training
    %*******************************************************
    
    Traj_Dir = cell2mat(Traj_Directory);
    
    imdsTrain = imageDatastore('Group_A','IncludeSubfolders',true,'LabelSource','foldernames');
    imdsTest = imageDatastore('Group_B','IncludeSubfolders',true,'LabelSource','foldernames');
    
    
    augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain);
    augimdsTest = augmentedImageDatastore(inputSize(1:2),imdsTest);
    
    
    for LL = 1:33
        %*****************************
        if LL == 1
            layer{LL} = 'res2a_branch2a';  %B01
            
        elseif LL == 2
            layer{LL} = 'res2b_branch2a';  %B02
            
        elseif LL == 3
            layer{LL} = 'res2c_branch2a';  %B03
            
            %**********************************
            
        elseif LL == 4
            layer{LL} = 'res3a_branch2a';  %B04
            
        elseif LL == 5
            layer{LL} = 'res3b1_branch2a';  %B05
            
        elseif LL == 6
            layer{LL} = 'res3b2_branch2a';  %B06
            
        elseif LL == 7
            layer{LL} = 'res3b3_branch2a';  %B07
            
            
            %*************************************
            
        elseif LL == 8
            layer{LL} = 'res4a_branch2a';  %B08
            
        elseif LL == 9
            layer{LL} = 'res4b1_branch2a';  %B09
            
        elseif LL == 10
            layer{LL} = 'res4b2_branch2a';  %B10
            
        elseif LL == 11
            layer{LL} = 'res4b3_branch2a';   %B11
            
        elseif LL == 12
            layer{LL} = 'res4b4_branch2a';   %B12* important point
            
        elseif LL == 13
            layer{LL} = 'res4b5_branch2a';  %B13
            
        elseif LL == 14
            layer{LL} = 'res4b6_branch2a';  %B14
            
        elseif LL == 15
            layer{LL} = 'res4b7_branch2a';  %B15
            
        elseif LL == 16
            layer{LL} = 'res4b8_branch2a';   %B16
            
        elseif LL == 17
            layer{LL} = 'res4b9_branch2a';    %B17
            
        elseif LL == 18
            layer{LL} = 'res4b10_branch2a';   %B18
            
        elseif LL == 19
            layer{LL} = 'res4b11_branch2a';   %B19
            
        elseif LL == 20
            layer{LL} = 'res4b12_branch2a';   %B20
            
        elseif LL == 21
            layer{LL} = 'res4b13_branch2a';   %B21
            
        elseif LL == 22
            layer{LL} = 'res4b14_branch2a';    %B22
            
        elseif LL == 23
            layer{LL} = 'res4b15_branch2a';   %B23
            
            
        elseif LL == 24
            layer{LL} = 'res4b16_branch2a';    %B24
            
        elseif LL == 25
            layer{LL} = 'res4b17_branch2a';    %B25
            
        elseif LL == 26
            layer{LL} = 'res4b18_branch2a';     %B26
            
        elseif LL == 27
            layer{LL} = 'res4b19_branch2a';     %B27
            
        elseif LL == 28
            layer{LL} = 'res4b20_branch2a';    %B28
            
        elseif LL == 29
            layer{LL} = 'res4b21_branch2a';    %B29
            
        elseif LL == 30
            layer{LL} = 'res4b22_branch2a';    %B30
            
            %***********************************************
            
        elseif LL == 31
            layer{LL} = 'res5a_branch2a';      %B31
            
        elseif LL == 32
            layer{LL} = 'res5b_branch2a';     %B32
            
        elseif LL == 33
            layer{LL} = 'res5c_branch2a';     %B33
            
        end
        
    end
    
    for L = 1:33
        
        featuresTrain = activations(net,augimdsTrain,layer{1,L},'OutputAs','rows');
        featuresTest = activations(net,augimdsTest,layer{1,L},'OutputAs','rows');
        %
        YTrain = imdsTrain.Labels;
        YTest = imdsTest.Labels;
        %
        t = templateSVM('Standardize',true);
        rng(1)
        classifier = fitcecoc(featuresTrain,YTrain,'Learners',t);
        clc
        YPred = predict(classifier,featuresTest);
        idx = 1:Number_of_Signatures;
        for i = 1:numel(idx)
            label = char(YPred(idx(i)));
            Best_Match =  str2num(label(end-3:end));
            
            All_labels(i,1) = Best_Match
        end
        
        %%
        Head_Tag = vertcat({['AllDegreeSignature_of'   Traj_Dir]});
        Res = num2cell(All_labels);
        New_Results = [Head_Tag; Res];
        %     % Save to Excel file
        cd (Experiment_Address)
        xlswrite(['T' num2str(Testing_Time_Point) '_all_matching_possibilities_for' Traj_Dir], New_Results, L)
    end
    
    clear From_To_Connection_Matrix
    clear New_Results
    clear All_labels
    cd (Root)
    
end